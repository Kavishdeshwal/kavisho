document.body.onload = function(){
    document.body.style.opacity="1";

}