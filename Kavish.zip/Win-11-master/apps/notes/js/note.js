class Note{
    constructor(title,note,date,alignment){
        this.title = title;
        this.note = note;
        this.align = alignment;
        this.date = date;
    }
}
//var n = new Note("Abinash","This is some text",new Date(),"center");
//console.log(n.align);
