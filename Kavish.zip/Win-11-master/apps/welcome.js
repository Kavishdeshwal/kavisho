let wallpaper = window.parent.document.body;

function changeWallpaper(n){
    wallpaper.style.backgroundImage = "url('wallpaper/" + n + ".webp')";
}