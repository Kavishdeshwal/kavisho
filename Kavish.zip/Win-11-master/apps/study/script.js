function ok(i){
    alert(i);
}